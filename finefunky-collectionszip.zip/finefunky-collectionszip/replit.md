# FineFunky Collections

## Overview

FineFunky Collections is a wholesale e-commerce platform for premium bags including handbags, backpacks, office bags, travel bags, and school bags. The application targets B2B retailers with features like minimum order quantities (MOQ), bulk ordering, and wholesale pricing. It's built as a single-page React application with client-side routing and a simple checkout flow that integrates with external payment and order management services.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 19 with TypeScript
- **Build Tool**: Vite 6 for fast development and optimized production builds
- **Routing**: React Router DOM v7 with HashRouter for client-side navigation
- **Styling**: Tailwind CSS (via CDN) with custom Google Fonts (Inter, Playfair Display)
- **Icons**: Lucide React for consistent iconography

### State Management
- **Cart State**: React Context API (`CartContext`) for global cart state management
- **Local Component State**: React `useState` for form inputs and UI toggles
- **URL State**: React Router's `useSearchParams` for filter persistence in product listings

### Page Structure
- `Home.tsx` - Landing page with hero section, features, and product highlights
- `Products.tsx` - Product catalog with category filtering, search, and sorting
- `ProductDetail.tsx` - Individual product view with quantity selection and add-to-cart
- `Cart.tsx` - Shopping cart with quantity management and order summary
- `Checkout.tsx` - Order form with customer details and payment integration

### Data Architecture
- **Static Product Data**: Products defined in `constants.ts` as a typed array
- **Type Definitions**: TypeScript interfaces in `types.ts` for Product, CartItem, Category enum, and form data
- **No Backend Database**: Currently a frontend-only application with hardcoded product catalog

### Path Aliasing
- Uses `@/*` path alias mapped to project root for cleaner imports

## External Dependencies

### Third-Party Services
- **Google Apps Script**: Configured endpoint (`APPS_SCRIPT_URL` in constants.ts) for order submission - requires user to replace placeholder with actual deployment ID
- **PayPal Checkout**: External payment link for order completion (`PAYMENT_LINK` in constants.ts)

### APIs
- **Gemini API**: Environment variable `GEMINI_API_KEY` configured in Vite but not currently utilized in visible code - likely planned for AI features

### CDN Resources
- **Tailwind CSS**: Loaded via CDN script tag
- **Google Fonts**: Inter and Playfair Display font families
- **Unsplash Images**: Product images sourced from Unsplash URLs

### Development Dependencies
- Vite with React plugin for HMR and builds
- TypeScript for type safety
- Node.js types for development environment