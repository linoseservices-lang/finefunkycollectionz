
export enum Category {
  Handbags = 'Handbags',
  Backpacks = 'Backpacks',
  TravelBags = 'Travel Bags',
  OfficeBags = 'Office Bags',
  SchoolBags = 'School Bags'
}

export interface Product {
  id: string;
  name: string;
  category: Category;
  price: number;
  moq: number;
  description: string;
  image: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface CheckoutFormData {
  firstName: string;
  lastName: string;
  businessName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  zipCode: string;
}

export interface OrderSubmission extends CheckoutFormData {
  items: {
    name: string;
    quantity: number;
    price: number;
  }[];
  totalAmount: number;
}
