
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Star, ShieldCheck, Truck, PackageCheck } from 'lucide-react';
import { PRODUCTS } from '../constants';
import { Category } from '../types';

const Hero = () => (
  <div className="relative bg-indigo-900 overflow-hidden">
    <div className="absolute inset-0 z-0 opacity-20">
      <img src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1600&q=80" alt="Warehouse" className="w-full h-full object-cover" />
    </div>
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32 relative z-10">
      <div className="max-w-2xl text-white">
        <span className="inline-block bg-indigo-500/30 border border-indigo-400/50 px-4 py-1 rounded-full text-indigo-200 text-xs font-bold uppercase tracking-widest mb-6">Wholesale Only</span>
        <h1 className="text-5xl md:text-7xl font-serif font-bold mb-8 leading-tight">
          Premium Bags for Your <span className="text-indigo-400">Retail Brand.</span>
        </h1>
        <p className="text-xl text-indigo-100 mb-10 leading-relaxed max-w-lg">
          Join 500+ retailers worldwide sourcing high-quality handbags, backpacks, and office carriers from FineFunky Collections.
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <Link to="/products" className="bg-white text-indigo-900 px-8 py-4 rounded-full font-bold text-lg hover:bg-indigo-50 transition flex items-center justify-center gap-2">
            Explore Collection <ArrowRight className="w-5 h-5" />
          </Link>
          <Link to="/products" className="bg-indigo-700/50 backdrop-blur-sm border border-indigo-500 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-indigo-700/70 transition text-center">
            Wholesale Catalog
          </Link>
        </div>
      </div>
    </div>
  </div>
);

const Features = () => (
  <div className="bg-white py-20">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-indigo-50 rounded-2xl flex items-center justify-center mb-6">
            <Star className="w-8 h-8 text-indigo-600" />
          </div>
          <h3 className="text-lg font-bold mb-2">Premium Quality</h3>
          <p className="text-gray-500 text-sm">Finest materials and expert craftsmanship in every stitch.</p>
        </div>
        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-indigo-50 rounded-2xl flex items-center justify-center mb-6">
            <PackageCheck className="w-8 h-8 text-indigo-600" />
          </div>
          <h3 className="text-lg font-bold mb-2">Low MOQ</h3>
          <p className="text-gray-500 text-sm">Flexible minimum order quantities starting from just 5-30 units.</p>
        </div>
        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-indigo-50 rounded-2xl flex items-center justify-center mb-6">
            <Truck className="w-8 h-8 text-indigo-600" />
          </div>
          <h3 className="text-lg font-bold mb-2">Global Shipping</h3>
          <p className="text-gray-500 text-sm">Reliable worldwide logistics and real-time order tracking.</p>
        </div>
        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-indigo-50 rounded-2xl flex items-center justify-center mb-6">
            <ShieldCheck className="w-8 h-8 text-indigo-600" />
          </div>
          <h3 className="text-lg font-bold mb-2">Trade Assurance</h3>
          <p className="text-gray-500 text-sm">Secure payments and 100% product protection for all buyers.</p>
        </div>
      </div>
    </div>
  </div>
);

const CategoryPreview = () => (
  <div className="py-20 bg-slate-50">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex justify-between items-end mb-12">
        <div>
          <h2 className="text-3xl font-serif font-bold text-slate-900 mb-4">Shop by Category</h2>
          <p className="text-slate-500">Find the perfect specialized collection for your customers.</p>
        </div>
        <Link to="/products" className="hidden sm:flex items-center gap-2 text-indigo-600 font-bold hover:underline">
          View All <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {Object.values(Category).map((cat) => (
          <Link 
            key={cat} 
            to={`/products?category=${encodeURIComponent(cat)}`}
            className="group relative h-48 rounded-2xl overflow-hidden bg-indigo-900 flex items-center justify-center text-center p-4 hover:shadow-xl transition duration-500"
          >
            <div className="absolute inset-0 opacity-40 group-hover:opacity-60 transition-opacity duration-500 bg-black"></div>
            <span className="relative z-10 text-white font-bold text-lg md:text-xl group-hover:scale-110 transition duration-500">{cat}</span>
          </Link>
        ))}
      </div>
    </div>
  </div>
);

const FeaturedProducts = () => {
  const featured = PRODUCTS.slice(0, 4);
  return (
    <div className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-serif font-bold text-slate-900 mb-4">Our Best Sellers</h2>
          <p className="text-slate-500 max-w-2xl mx-auto">High-demand items currently trending in wholesale markets worldwide.</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {featured.map((p) => (
            <Link key={p.id} to={`/product/${p.id}`} className="group block">
              <div className="relative aspect-[4/5] rounded-2xl overflow-hidden mb-6 bg-slate-100">
                <img src={p.image} alt={p.name} className="w-full h-full object-cover group-hover:scale-110 transition duration-700" />
                <div className="absolute top-4 right-4">
                  <span className="bg-white/90 backdrop-blur px-3 py-1.5 rounded-full text-indigo-900 font-bold text-xs">MOQ: {p.moq}</span>
                </div>
              </div>
              <p className="text-xs text-indigo-600 font-bold uppercase tracking-wider mb-2">{p.category}</p>
              <h3 className="text-lg font-bold mb-2 group-hover:text-indigo-600 transition">{p.name}</h3>
              <p className="text-xl font-bold text-indigo-900">${p.price.toFixed(2)} <span className="text-xs text-slate-400 font-normal">/ unit</span></p>
            </Link>
          ))}
        </div>
        <div className="mt-16 text-center">
          <Link to="/products" className="inline-flex items-center gap-2 bg-indigo-900 text-white px-10 py-4 rounded-full font-bold hover:bg-indigo-800 transition shadow-lg shadow-indigo-900/20">
            View Full Catalog
          </Link>
        </div>
      </div>
    </div>
  );
};

const Home = () => {
  return (
    <div className="animate-in fade-in duration-700">
      <Hero />
      <Features />
      <CategoryPreview />
      <FeaturedProducts />
      
      {/* Newsletter / CTA */}
      <div className="bg-indigo-600 py-20 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-6">Ready to scale your business?</h2>
          <p className="text-indigo-100 mb-10 max-w-2xl mx-auto text-lg">
            Create a wholesale account today and get access to exclusive bulk pricing, custom logistics, and new arrivals before anyone else.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/products" className="bg-white text-indigo-600 px-10 py-4 rounded-full font-bold text-lg hover:bg-slate-50 transition">
              Get Started
            </Link>
            <button className="bg-indigo-500 border border-indigo-400 text-white px-10 py-4 rounded-full font-bold text-lg hover:bg-indigo-400 transition">
              Contact Sales
            </button>
          </div>
        </div>
        {/* Abstract shapes */}
        <div className="absolute top-0 left-0 w-64 h-64 bg-white/5 rounded-full -translate-x-1/2 -translate-y-1/2"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-white/5 rounded-full translate-x-1/4 translate-y-1/4"></div>
      </div>
    </div>
  );
};

export default Home;
