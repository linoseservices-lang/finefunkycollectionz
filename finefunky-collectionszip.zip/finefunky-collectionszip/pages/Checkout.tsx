
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard, Truck, CheckCircle, ExternalLink, ArrowLeft, Loader2 } from 'lucide-react';
import { useCart } from '../App';
import { APPS_SCRIPT_URL, PAYMENT_LINK } from '../constants';
import { CheckoutFormData, OrderSubmission } from '../types';

const Checkout = () => {
  const { cart, cartTotal, clearCart } = useCart();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [formData, setFormData] = useState<CheckoutFormData>({
    firstName: '',
    lastName: '',
    businessName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    zipCode: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handlePayNow = () => {
    window.open(PAYMENT_LINK, '_blank');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const submission: OrderSubmission = {
      ...formData,
      items: cart.map(item => ({
        name: item.product.name,
        quantity: item.quantity,
        price: item.product.price
      })),
      totalAmount: cartTotal
    };

    try {
      // Simulate/Trigger Apps Script submission
      // Note: In real scenarios, fetch with mode 'no-cors' for Apps Script might be needed 
      // if CORS isn't handled by the script.
      await fetch(APPS_SCRIPT_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(submission),
        mode: 'no-cors'
      });
      
      // We assume success if the fetch is fired off
      setTimeout(() => {
        setSuccess(true);
        setLoading(false);
        clearCart();
      }, 1500);
    } catch (error) {
      console.error('Submission failed', error);
      alert('Order recorded locally. (Script endpoint simulated/unavailable)');
      setSuccess(true);
      setLoading(false);
      clearCart();
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6 text-center animate-in zoom-in duration-500">
        <div className="w-24 h-24 bg-green-50 rounded-full flex items-center justify-center mb-8">
          <CheckCircle className="w-16 h-16 text-green-500" />
        </div>
        <h2 className="text-4xl font-serif font-bold text-slate-900 mb-4">Order Submitted Successfully!</h2>
        <p className="text-slate-500 max-w-md mx-auto mb-10 text-lg">
          Your wholesale order has been recorded. Our logistics team will review the details and contact you within 24 hours for shipping confirmation.
        </p>
        <button 
          onClick={() => navigate('/')}
          className="bg-indigo-900 text-white px-10 py-4 rounded-full font-bold shadow-lg shadow-indigo-900/20"
        >
          Return to Dashboard
        </button>
      </div>
    );
  }

  return (
    <div className="bg-slate-50 min-h-screen py-12 md:py-20 animate-in fade-in duration-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-12">
          <button onClick={() => navigate('/cart')} className="inline-flex items-center gap-2 text-sm text-slate-500 hover:text-indigo-600 mb-6 font-bold transition">
            <ArrowLeft className="w-4 h-4" /> Edit Cart
          </button>
          <h1 className="text-4xl font-serif font-bold text-slate-900">Checkout & Secure Payment</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-12">
            <section className="bg-white p-8 rounded-3xl shadow-sm">
              <h3 className="text-xl font-bold mb-8 flex items-center gap-3">
                <div className="w-8 h-8 bg-indigo-900 text-white rounded-full flex items-center justify-center text-sm">1</div>
                Business Information
              </h3>
              <div className="grid grid-cols-2 gap-6">
                <div className="col-span-1 space-y-2">
                  <label className="text-xs font-black uppercase text-slate-400 tracking-widest">First Name</label>
                  <input required name="firstName" value={formData.firstName} onChange={handleChange} className="w-full bg-slate-50 border-none rounded-xl p-4 focus:ring-2 focus:ring-indigo-600" />
                </div>
                <div className="col-span-1 space-y-2">
                  <label className="text-xs font-black uppercase text-slate-400 tracking-widest">Last Name</label>
                  <input required name="lastName" value={formData.lastName} onChange={handleChange} className="w-full bg-slate-50 border-none rounded-xl p-4 focus:ring-2 focus:ring-indigo-600" />
                </div>
                <div className="col-span-2 space-y-2">
                  <label className="text-xs font-black uppercase text-slate-400 tracking-widest">Company / Business Name</label>
                  <input required name="businessName" value={formData.businessName} onChange={handleChange} className="w-full bg-slate-50 border-none rounded-xl p-4 focus:ring-2 focus:ring-indigo-600" />
                </div>
                <div className="col-span-1 space-y-2">
                  <label className="text-xs font-black uppercase text-slate-400 tracking-widest">Work Email Address</label>
                  <input required type="email" name="email" value={formData.email} onChange={handleChange} className="w-full bg-slate-50 border-none rounded-xl p-4 focus:ring-2 focus:ring-indigo-600" />
                </div>
                <div className="col-span-1 space-y-2">
                  <label className="text-xs font-black uppercase text-slate-400 tracking-widest">Phone Number</label>
                  <input required type="tel" name="phone" value={formData.phone} onChange={handleChange} className="w-full bg-slate-50 border-none rounded-xl p-4 focus:ring-2 focus:ring-indigo-600" />
                </div>
              </div>
            </section>

            <section className="bg-white p-8 rounded-3xl shadow-sm">
              <h3 className="text-xl font-bold mb-8 flex items-center gap-3">
                <div className="w-8 h-8 bg-indigo-900 text-white rounded-full flex items-center justify-center text-sm">2</div>
                Delivery Address
              </h3>
              <div className="grid grid-cols-2 gap-6">
                <div className="col-span-2 space-y-2">
                  <label className="text-xs font-black uppercase text-slate-400 tracking-widest">Full Street Address</label>
                  <input required name="address" value={formData.address} onChange={handleChange} className="w-full bg-slate-50 border-none rounded-xl p-4 focus:ring-2 focus:ring-indigo-600" />
                </div>
                <div className="col-span-1 space-y-2">
                  <label className="text-xs font-black uppercase text-slate-400 tracking-widest">City</label>
                  <input required name="city" value={formData.city} onChange={handleChange} className="w-full bg-slate-50 border-none rounded-xl p-4 focus:ring-2 focus:ring-indigo-600" />
                </div>
                <div className="col-span-1 space-y-2">
                  <label className="text-xs font-black uppercase text-slate-400 tracking-widest">Zip / Postal Code</label>
                  <input required name="zipCode" value={formData.zipCode} onChange={handleChange} className="w-full bg-slate-50 border-none rounded-xl p-4 focus:ring-2 focus:ring-indigo-600" />
                </div>
              </div>
            </section>

            <section className="bg-white p-8 rounded-3xl shadow-sm">
               <h3 className="text-xl font-bold mb-8 flex items-center gap-3">
                <div className="w-8 h-8 bg-indigo-900 text-white rounded-full flex items-center justify-center text-sm">3</div>
                Finalize & Pay
              </h3>
              <div className="space-y-6">
                <div className="p-6 border-2 border-indigo-100 rounded-2xl bg-indigo-50/50 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="bg-white p-3 rounded-xl shadow-sm">
                      <CreditCard className="w-6 h-6 text-indigo-600" />
                    </div>
                    <div>
                      <p className="font-bold">Secure Global Payment</p>
                      <p className="text-xs text-slate-500">Redirects to PayPal / Visa / Mastercard</p>
                    </div>
                  </div>
                  <button 
                    type="button" 
                    onClick={handlePayNow}
                    className="flex items-center gap-2 bg-indigo-900 text-white px-6 py-2 rounded-xl font-bold text-sm hover:bg-indigo-800 transition"
                  >
                    Pay Now <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
                <button 
                  type="submit"
                  disabled={loading}
                  className="w-full bg-indigo-900 text-white py-5 rounded-2xl font-bold text-xl hover:bg-indigo-800 transition flex items-center justify-center gap-3 disabled:opacity-50"
                >
                  {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : 'Confirm Order Submission'}
                </button>
                <p className="text-center text-xs text-slate-400">
                  By clicking submit, you agree to our Wholesale Terms of Service and data processing policies.
                </p>
              </div>
            </section>
          </form>

          {/* Sticky Summary */}
          <div className="lg:block">
            <div className="bg-white p-8 rounded-3xl shadow-sm sticky top-24">
               <h3 className="text-2xl font-serif font-bold text-slate-900 mb-8 flex items-center gap-2">
                <Truck className="w-6 h-6" /> Your Order Summary
              </h3>
              <div className="max-h-[300px] overflow-y-auto pr-2 space-y-4 mb-8 custom-scrollbar">
                {cart.map(item => (
                  <div key={item.product.id} className="flex gap-4">
                    <div className="w-16 h-16 rounded-lg bg-slate-50 flex-shrink-0">
                      <img src={item.product.image} className="w-full h-full object-cover rounded-lg" />
                    </div>
                    <div className="flex-grow">
                      <h4 className="font-bold text-sm line-clamp-1">{item.product.name}</h4>
                      <p className="text-xs text-slate-400">{item.quantity} units x ${item.product.price.toFixed(2)}</p>
                    </div>
                    <div className="font-bold text-slate-900 text-sm">
                      ${(item.quantity * item.product.price).toFixed(2)}
                    </div>
                  </div>
                ))}
              </div>
              <div className="border-t pt-6 space-y-4">
                 <div className="flex justify-between text-slate-500 text-sm">
                    <span>Subtotal</span>
                    <span>${cartTotal.toFixed(2)}</span>
                 </div>
                 <div className="flex justify-between text-slate-500 text-sm">
                    <span>Processing Fee</span>
                    <span>$0.00</span>
                 </div>
                 <div className="flex justify-between pt-4 border-t-2 border-slate-100">
                    <span className="text-lg font-bold">Grand Total</span>
                    <span className="text-2xl font-serif font-bold text-indigo-900">${cartTotal.toFixed(2)}</span>
                 </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
