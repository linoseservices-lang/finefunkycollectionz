
import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ChevronLeft, Plus, Minus, ShoppingCart, ShieldCheck, Truck, RefreshCcw } from 'lucide-react';
import { PRODUCTS } from '../constants';
import { useCart } from '../App';

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const product = PRODUCTS.find(p => p.id === id);
  const [quantity, setQuantity] = useState(product?.moq || 1);

  if (!product) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
          <Link to="/products" className="text-indigo-600 hover:underline">Return to Shop</Link>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart(product, quantity);
    navigate('/cart');
  };

  return (
    <div className="bg-white min-h-screen pb-24 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        <Link to="/products" className="inline-flex items-center gap-2 text-sm text-slate-500 hover:text-indigo-600 mb-12 transition">
          <ChevronLeft className="w-4 h-4" /> Back to Collections
        </Link>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
          {/* Image Section */}
          <div className="space-y-6">
            <div className="aspect-[4/5] rounded-3xl overflow-hidden bg-slate-50 shadow-sm">
              <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
            </div>
            <div className="grid grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="aspect-square rounded-xl overflow-hidden bg-slate-50 cursor-pointer border-2 border-transparent hover:border-indigo-600 transition">
                  <img src={product.image} alt={`${product.name} thumbnail`} className="w-full h-full object-cover opacity-60" />
                </div>
              ))}
            </div>
          </div>

          {/* Info Section */}
          <div className="flex flex-col">
            <div className="border-b pb-8 mb-8">
              <span className="inline-block bg-indigo-50 text-indigo-600 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full mb-6">
                {product.category}
              </span>
              <h1 className="text-4xl md:text-5xl font-serif font-bold text-slate-900 mb-4">{product.name}</h1>
              <div className="flex items-end gap-3 mb-6">
                <span className="text-3xl font-bold text-indigo-900">${product.price.toFixed(2)}</span>
                <span className="text-slate-400 text-sm mb-1.5 uppercase tracking-tighter font-bold">Per Unit (Wholesale)</span>
              </div>
              <p className="text-slate-600 leading-relaxed text-lg">{product.description}</p>
            </div>

            <div className="space-y-8 mb-12">
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h4 className="font-bold text-slate-900">Wholesale Quantity</h4>
                    <p className="text-xs text-slate-500">Min. Order Quantity: {product.moq} units</p>
                  </div>
                  <div className="flex items-center gap-4 bg-white border rounded-xl p-2 shadow-sm">
                    <button 
                      onClick={() => setQuantity(q => Math.max(product.moq, q - 1))}
                      className="p-1.5 hover:bg-slate-50 rounded-lg transition"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="w-8 text-center font-bold">{quantity}</span>
                    <button 
                      onClick={() => setQuantity(q => q + 1)}
                      className="p-1.5 hover:bg-slate-50 rounded-lg transition"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <div className="flex justify-between items-center pt-6 border-t">
                  <span className="text-slate-500 font-medium">Subtotal Estimate</span>
                  <span className="text-2xl font-bold text-indigo-950">${(product.price * quantity).toFixed(2)}</span>
                </div>
              </div>

              <button 
                onClick={handleAddToCart}
                className="w-full bg-indigo-900 text-white py-5 rounded-2xl font-bold text-lg hover:bg-indigo-800 transition shadow-xl shadow-indigo-900/20 flex items-center justify-center gap-3"
              >
                <ShoppingCart className="w-6 h-6" /> Add to Wholesale Order
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div className="flex flex-col items-center text-center p-4">
                <Truck className="w-6 h-6 text-indigo-600 mb-2" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-900">7-14 Days</span>
                <span className="text-[9px] text-slate-400">Global Shipping</span>
              </div>
              <div className="flex flex-col items-center text-center p-4">
                <ShieldCheck className="w-6 h-6 text-indigo-600 mb-2" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-900">Secure</span>
                <span className="text-[9px] text-slate-400">Transaction</span>
              </div>
              <div className="flex flex-col items-center text-center p-4">
                <RefreshCcw className="w-6 h-6 text-indigo-600 mb-2" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-900">Quality</span>
                <span className="text-[9px] text-slate-400">Inspected</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
