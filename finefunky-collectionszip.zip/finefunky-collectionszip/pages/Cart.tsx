
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Trash2, Plus, Minus, ArrowLeft, ShoppingBag } from 'lucide-react';
import { useCart } from '../App';

const Cart = () => {
  const { cart, removeFromCart, updateQuantity, cartTotal } = useCart();
  const navigate = useNavigate();

  if (cart.length === 0) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center bg-white px-4">
        <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center mb-8">
          <ShoppingBag className="w-12 h-12 text-slate-300" />
        </div>
        <h2 className="text-3xl font-serif font-bold text-slate-900 mb-4">Your cart is empty</h2>
        <p className="text-slate-500 mb-10 max-w-sm text-center">It looks like you haven't added any products to your wholesale order yet.</p>
        <Link to="/products" className="bg-indigo-900 text-white px-10 py-4 rounded-full font-bold shadow-lg shadow-indigo-900/20 hover:bg-indigo-800 transition">
          Browse Collections
        </Link>
      </div>
    );
  }

  return (
    <div className="bg-slate-50 min-h-screen py-12 md:py-20 animate-in fade-in duration-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-serif font-bold text-slate-900 mb-12">Wholesale Order Summary</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cart.map((item) => (
              <div key={item.product.id} className="bg-white p-6 rounded-3xl shadow-sm flex flex-col sm:flex-row gap-6 items-center">
                <div className="w-full sm:w-32 h-32 rounded-2xl overflow-hidden flex-shrink-0 bg-slate-50">
                  <img src={item.product.image} alt={item.product.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-grow text-center sm:text-left">
                  <p className="text-[10px] text-indigo-600 font-black uppercase tracking-widest mb-1">{item.product.category}</p>
                  <h3 className="text-xl font-bold text-slate-900 mb-2">{item.product.name}</h3>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-6 text-sm text-slate-500">
                    <span>Unit Price: ${item.product.price.toFixed(2)}</span>
                    <span className="hidden sm:block">|</span>
                    <span className="text-indigo-600 font-semibold">Min: {item.product.moq} units</span>
                  </div>
                </div>
                <div className="flex flex-col items-center sm:items-end gap-4">
                  <div className="flex items-center gap-3 bg-slate-50 p-1.5 rounded-xl border">
                    <button 
                      onClick={() => updateQuantity(item.product.id, Math.max(item.product.moq, item.quantity - 1))}
                      className="p-1 hover:bg-white rounded-md transition"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="w-10 text-center font-bold">{item.quantity}</span>
                    <button 
                      onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                      className="p-1 hover:bg-white rounded-md transition"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-lg font-bold text-indigo-950">${(item.product.price * item.quantity).toFixed(2)}</span>
                    <button 
                      onClick={() => removeFromCart(item.product.id)}
                      className="text-slate-300 hover:text-red-500 transition"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
            
            <Link to="/products" className="inline-flex items-center gap-2 text-indigo-600 font-bold hover:underline py-4">
              <ArrowLeft className="w-4 h-4" /> Add more products
            </Link>
          </div>

          {/* Order Total */}
          <div className="lg:col-span-1">
            <div className="bg-white p-8 rounded-3xl shadow-sm sticky top-24">
              <h3 className="text-2xl font-serif font-bold text-slate-900 mb-8 pb-4 border-b">Order Summary</h3>
              <div className="space-y-4 mb-8">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal</span>
                  <span className="font-bold">${cartTotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Estimated Shipping</span>
                  <span className="text-indigo-600 font-semibold">Calculated at checkout</span>
                </div>
                <div className="flex justify-between text-slate-600 pb-4">
                  <span>Wholesale Discount</span>
                  <span className="text-green-600 font-semibold">-$0.00</span>
                </div>
                <div className="flex justify-between pt-6 border-t">
                  <span className="text-xl font-bold text-slate-900 uppercase tracking-tighter">Total Amount</span>
                  <span className="text-3xl font-serif font-bold text-indigo-900">${cartTotal.toFixed(2)}</span>
                </div>
              </div>

              <div className="bg-indigo-50 p-4 rounded-2xl mb-8">
                <p className="text-xs text-indigo-700 leading-relaxed font-medium">
                  <strong>Notice:</strong> As a wholesale provider, all orders are subject to stock availability and logistics confirmation after payment processing.
                </p>
              </div>

              <button 
                onClick={() => navigate('/checkout')}
                className="w-full bg-indigo-900 text-white py-5 rounded-2xl font-bold text-lg hover:bg-indigo-800 transition shadow-xl shadow-indigo-900/20"
              >
                Proceed to Checkout
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
