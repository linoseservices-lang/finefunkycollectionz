
import React, { useState, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Filter, Search, SlidersHorizontal, ChevronRight } from 'lucide-react';
import { PRODUCTS } from '../constants';
import { Category } from '../types';

const Products = () => {
  const [searchParams] = useSearchParams();
  const initialCategory = searchParams.get('category') || 'All';
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('featured');

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter(p => {
      const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
      const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    }).sort((a, b) => {
      if (sortBy === 'price-low') return a.price - b.price;
      if (sortBy === 'price-high') return b.price - a.price;
      if (sortBy === 'moq-low') return a.moq - b.moq;
      return 0; // featured
    });
  }, [selectedCategory, searchQuery, sortBy]);

  return (
    <div className="min-h-screen bg-white pb-24 animate-in fade-in duration-500">
      {/* Breadcrumbs / Header */}
      <div className="bg-slate-50 py-12 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 text-xs font-medium text-slate-500 uppercase tracking-widest mb-4">
            <Link to="/" className="hover:text-indigo-600">Home</Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-slate-900">Collections</span>
          </div>
          <h1 className="text-4xl font-serif font-bold text-slate-900">Wholesale Collection</h1>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col lg:flex-row gap-12">
          {/* Sidebar Filters */}
          <aside className="w-full lg:w-64 space-y-10">
            <div>
              <h3 className="text-sm font-bold uppercase tracking-widest text-slate-900 mb-6 flex items-center gap-2">
                <Filter className="w-4 h-4" /> Categories
              </h3>
              <div className="space-y-3">
                <button 
                  onClick={() => setSelectedCategory('All')}
                  className={`block w-full text-left py-2 px-3 rounded-lg text-sm transition ${selectedCategory === 'All' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-slate-600 hover:bg-slate-50'}`}
                >
                  All Collections
                </button>
                {Object.values(Category).map(cat => (
                  <button 
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`block w-full text-left py-2 px-3 rounded-lg text-sm transition ${selectedCategory === cat ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-slate-600 hover:bg-slate-50'}`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <div className="p-6 bg-indigo-900 rounded-3xl text-white">
              <h4 className="font-serif font-bold text-lg mb-2">Bulk Savings</h4>
              <p className="text-indigo-200 text-xs mb-4">Ordering over 500 units? Contact our sourcing team for custom manufacturing quotes.</p>
              <button className="w-full py-2 bg-indigo-700 rounded-xl text-xs font-bold hover:bg-indigo-600 transition">Contact Sourcing</button>
            </div>
          </aside>

          {/* Main Content */}
          <div className="flex-1">
            {/* Toolbar */}
            <div className="flex flex-col sm:flex-row justify-between items-center gap-6 mb-12">
              <div className="relative w-full sm:max-w-xs">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Search bags..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-600 text-sm"
                />
              </div>
              <div className="flex items-center gap-4 w-full sm:w-auto">
                <div className="flex items-center gap-2 text-sm text-slate-500">
                  <SlidersHorizontal className="w-4 h-4" />
                  <span>Sort by:</span>
                </div>
                <select 
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="bg-white border rounded-xl py-2 px-4 text-sm focus:ring-2 focus:ring-indigo-600 outline-none"
                >
                  <option value="featured">Featured</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="moq-low">Lowest MOQ</option>
                </select>
              </div>
            </div>

            {/* Product Grid */}
            {filteredProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
                {filteredProducts.map((p) => (
                  <Link key={p.id} to={`/product/${p.id}`} className="group">
                    <div className="relative aspect-[4/5] rounded-3xl overflow-hidden mb-6 bg-slate-100 shadow-sm transition duration-500 group-hover:shadow-xl">
                      <img src={p.image} alt={p.name} className="w-full h-full object-cover group-hover:scale-110 transition duration-700" />
                      <div className="absolute top-4 right-4">
                        <span className="bg-white/90 backdrop-blur px-3 py-1.5 rounded-full text-indigo-900 font-bold text-xs shadow-sm">MOQ: {p.moq}</span>
                      </div>
                    </div>
                    <div className="px-1">
                      <p className="text-[10px] text-indigo-600 font-black uppercase tracking-widest mb-1.5">{p.category}</p>
                      <h3 className="text-lg font-bold text-slate-900 mb-2 group-hover:text-indigo-600 transition">{p.name}</h3>
                      <div className="flex items-end gap-2">
                        <p className="text-xl font-bold text-indigo-950">${p.price.toFixed(2)}</p>
                        <p className="text-xs text-slate-400 mb-1">/ unit (wholesale)</p>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="py-24 text-center">
                <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6">
                   <Search className="w-8 h-8 text-slate-300" />
                </div>
                <h3 className="text-xl font-bold mb-2">No products found</h3>
                <p className="text-slate-500">Try adjusting your filters or search keywords.</p>
                <button onClick={() => {setSearchQuery(''); setSelectedCategory('All');}} className="mt-6 text-indigo-600 font-bold hover:underline">Clear all filters</button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Products;
