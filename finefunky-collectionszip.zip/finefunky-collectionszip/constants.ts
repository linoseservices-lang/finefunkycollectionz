
import { Product, Category } from './types';

export const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/YOUR_ACTUAL_ID/exec';
export const PAYMENT_LINK = 'https://www.paypal.com/checkout';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Elite Leather Handbag',
    category: Category.Handbags,
    price: 45.00,
    moq: 10,
    description: 'Supple full-grain leather handbag with gold-tone hardware. Perfect for upscale retail collections.',
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '2',
    name: 'Urban Explorer Backpack',
    category: Category.Backpacks,
    price: 32.50,
    moq: 15,
    description: 'Weather-resistant nylon backpack with ergonomic straps and multi-compartment design.',
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '3',
    name: 'Executive Laptop Briefcase',
    category: Category.OfficeBags,
    price: 55.00,
    moq: 5,
    description: 'Professional padded briefcase with dedicated laptop sleeve and RFID-blocking pockets.',
    image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '4',
    name: 'Weekend Travel Duffel',
    category: Category.TravelBags,
    price: 38.00,
    moq: 12,
    description: 'Spacious canvas duffel bag with reinforced handles and detachable shoulder strap.',
    image: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '5',
    name: 'Junior Scholar School Bag',
    category: Category.SchoolBags,
    price: 18.00,
    moq: 20,
    description: 'Lightweight, durable backpack with reflective safety strips and breathable mesh back.',
    image: 'https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '6',
    name: 'Classic Suede Tote',
    category: Category.Handbags,
    price: 28.00,
    moq: 15,
    description: 'Elegant suede tote bag available in various seasonal colors. Ideal for everyday use.',
    image: 'https://images.unsplash.com/photo-1591561954557-26941169b49e?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '7',
    name: 'Rugged Trail Pack',
    category: Category.Backpacks,
    price: 42.00,
    moq: 10,
    description: 'Heavy-duty hiking backpack with integrated rain cover and hydration bladder compartment.',
    image: 'https://images.unsplash.com/photo-1509223197845-458d87318791?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '8',
    name: 'Slim Office Carrier',
    category: Category.OfficeBags,
    price: 22.00,
    moq: 25,
    description: 'Minimalist laptop sleeve with accessory pockets. Modern design for the tech-savvy professional.',
    image: 'https://images.unsplash.com/photo-1512331283953-19967202267a?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '9',
    name: 'Luxury Roller Suitcase',
    category: Category.TravelBags,
    price: 85.00,
    moq: 4,
    description: 'Hard-shell polycarbonate suitcase with 360-degree spinner wheels and TSA-approved locks.',
    image: 'https://images.unsplash.com/photo-1565026057447-bc90a3dceb87?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '10',
    name: 'Vibrant Primary Backpack',
    category: Category.SchoolBags,
    price: 15.00,
    moq: 30,
    description: 'Colorful and fun school bag designed for primary students. Water-repellent material.',
    image: 'https://images.unsplash.com/photo-1588072432836-e10032774350?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '11',
    name: 'Vegan Leather Crossbody',
    category: Category.Handbags,
    price: 24.00,
    moq: 20,
    description: 'Sustainable vegan leather crossbody bag. Chic, compact, and highly marketable.',
    image: 'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '12',
    name: 'Tech-Master Pro Backpack',
    category: Category.Backpacks,
    price: 48.00,
    moq: 8,
    description: 'High-tech backpack with integrated USB charging port and anti-theft hidden zippers.',
    image: 'https://images.unsplash.com/photo-1575844444493-61a059263628?auto=format&fit=crop&w=800&q=80'
  }
];
