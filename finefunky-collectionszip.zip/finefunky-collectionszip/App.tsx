
import React, { useState, useEffect, createContext, useContext } from 'react';
import { HashRouter, Routes, Route, Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, Menu, X, Facebook, Instagram, Twitter, Phone, Mail, MapPin } from 'lucide-react';
import { CartItem, Product } from './types';
import Home from './pages/Home';
import Products from './pages/Products';
import ProductDetail from './pages/ProductDetail';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';

// Cart Context
interface CartContextType {
  cart: CartItem[];
  addToCart: (product: Product, quantity: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartTotal: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) throw new Error('useCart must be used within a CartProvider');
  return context;
};

const Header = () => {
  const { cart } = useCart();
  const [isOpen, setIsOpen] = useState(false);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <nav className="bg-white border-b sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center gap-2">
              <span className="text-2xl font-serif font-bold tracking-tighter text-indigo-900">FineFunky</span>
              <span className="bg-indigo-600 text-white text-[10px] px-1.5 py-0.5 rounded font-bold uppercase tracking-widest">Collections</span>
            </Link>
          </div>
          <div className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-gray-700 hover:text-indigo-600 font-medium transition">Home</Link>
            <Link to="/products" className="text-gray-700 hover:text-indigo-600 font-medium transition">All Bags</Link>
            <Link to="/cart" className="relative p-2 text-gray-700 hover:text-indigo-600 transition">
              <ShoppingCart className="w-6 h-6" />
              {cartCount > 0 && (
                <span className="absolute top-0 right-0 bg-indigo-600 text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Link>
            <Link to="/products" className="bg-indigo-900 text-white px-6 py-2.5 rounded-full font-semibold text-sm hover:bg-indigo-800 transition">
              Bulk Order
            </Link>
          </div>
          <div className="md:hidden flex items-center gap-4">
            <Link to="/cart" className="relative p-2 text-gray-700">
               <ShoppingCart className="w-6 h-6" />
               {cartCount > 0 && (
                 <span className="absolute top-0 right-0 bg-indigo-600 text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center">
                   {cartCount}
                 </span>
               )}
            </Link>
            <button onClick={() => setIsOpen(!isOpen)} className="text-gray-700 p-1">
              {isOpen ? <X className="w-7 h-7" /> : <Menu className="w-7 h-7" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-b py-4 px-6 space-y-4 animate-in fade-in slide-in-from-top-4 duration-300">
          <Link to="/" onClick={() => setIsOpen(false)} className="block text-lg font-medium text-gray-800">Home</Link>
          <Link to="/products" onClick={() => setIsOpen(false)} className="block text-lg font-medium text-gray-800">All Bags</Link>
          <Link to="/cart" onClick={() => setIsOpen(false)} className="block text-lg font-medium text-gray-800">Shopping Cart</Link>
          <Link to="/products" onClick={() => setIsOpen(false)} className="block w-full text-center bg-indigo-900 text-white py-3 rounded-xl font-bold">Start Wholesale Order</Link>
        </div>
      )}
    </nav>
  );
};

const Footer = () => (
  <footer className="bg-slate-900 text-slate-300 pt-16 pb-8">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
        <div className="col-span-1 md:col-span-1">
          <Link to="/" className="flex items-center gap-2 mb-6">
            <span className="text-2xl font-serif font-bold tracking-tighter text-white">FineFunky</span>
          </Link>
          <p className="text-slate-400 text-sm leading-relaxed mb-6">
            Leading wholesaler of premium quality bags. We provide global supply chains with durable, stylish, and functional bags for every occasion.
          </p>
          <div className="flex gap-4">
            <Facebook className="w-5 h-5 hover:text-indigo-400 cursor-pointer transition" />
            <Instagram className="w-5 h-5 hover:text-indigo-400 cursor-pointer transition" />
            <Twitter className="w-5 h-5 hover:text-indigo-400 cursor-pointer transition" />
          </div>
        </div>
        <div>
          <h3 className="text-white font-bold mb-6">Quick Links</h3>
          <ul className="space-y-4 text-sm">
            <li><Link to="/" className="hover:text-white transition">Home</Link></li>
            <li><Link to="/products" className="hover:text-white transition">All Products</Link></li>
            <li><Link to="/products" className="hover:text-white transition">Categories</Link></li>
            <li><Link to="/cart" className="hover:text-white transition">Order Status</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="text-white font-bold mb-6">Customer Support</h3>
          <ul className="space-y-4 text-sm">
            <li>Wholesale Policy</li>
            <li>Shipping & Delivery</li>
            <li>Returns & Exchanges</li>
            <li>Bulk Orders FAQ</li>
          </ul>
        </div>
        <div>
          <h3 className="text-white font-bold mb-6">Contact Us</h3>
          <ul className="space-y-4 text-sm">
            <li className="flex items-center gap-3"><MapPin className="w-4 h-4 text-indigo-400" /> 123 Fashion District, NY</li>
            <li className="flex items-center gap-3"><Phone className="w-4 h-4 text-indigo-400" /> +1 (555) 123-4567</li>
            <li className="flex items-center gap-3"><Mail className="w-4 h-4 text-indigo-400" /> sales@finefunky.com</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-slate-500 gap-4">
        <p>© 2024 FineFunky Collections. All rights reserved.</p>
        <div className="flex gap-6">
          <span>Privacy Policy</span>
          <span>Terms of Service</span>
          <span>Cookie Policy</span>
        </div>
      </div>
    </div>
  </footer>
);

export default function App() {
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('ffc_cart');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('ffc_cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (product: Product, quantity: number) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    setCart(prev => prev.map(item =>
      item.product.id === productId ? { ...item, quantity: Math.max(1, quantity) } : item
    ));
  };

  const clearCart = () => setCart([]);

  const cartTotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);

  return (
    <CartContext.Provider value={{ cart, addToCart, removeFromCart, updateQuantity, clearCart, cartTotal }}>
      <HashRouter>
        <div className="flex flex-col min-h-screen">
          <Header />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/products" element={<Products />} />
              <Route path="/product/:id" element={<ProductDetail />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="/checkout" element={<Checkout />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </HashRouter>
    </CartContext.Provider>
  );
}
